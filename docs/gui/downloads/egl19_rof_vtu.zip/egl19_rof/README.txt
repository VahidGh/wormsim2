wormsim2 — VTK trajectory export
================================
Scenario : egl19_rof
Frames   : 80
Time     : 0.0 – 2.7 s
Coords   : x, y in BL (body lengths); z = 0
Fields   : worm_id (0=real, 1=simulated), keypoint_index (0=head … 48=tail)

ParaView
--------
  File > Open > egl19_rof.pvd
  Apply  →  Play (▶)
  Colour by worm_id to distinguish real (blue) from simulated (red).

PyVista (Python)
----------------
  import pyvista as pv
  reader = pv.PVDReader("egl19_rof.pvd")
  print(reader.time_values)          # list of timestamps

  pl = pv.Plotter()
  reader.set_active_time_point(0)
  mesh = reader.read()
  pl.add_mesh(mesh.threshold(0.5, scalars="worm_id"),
              color="steelblue", line_width=4, label="real")
  pl.add_mesh(mesh.threshold(0.5, scalars="worm_id", invert=True),
              color="crimson",   line_width=4, label="simulated")
  pl.show_axes(); pl.add_legend(); pl.show()

  # Animate all frames:
  for i, t in enumerate(reader.time_values):
      reader.set_active_time_point(i)
      mesh = reader.read()
      # ... process mesh ...

Source
------
  https://github.com/VahidGh/wormsim2
  Data: Zenodo 1031837 (Schafer Lab, C. elegans N2 WT 2014)
